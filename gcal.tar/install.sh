#!/bin/bash

# Go to the src directory where the Makefile is located
cd src

# Check if Makefile exists and compile using make
if [ -f "Makefile" ]; then
    echo "Makefile found. Building the project..."
    make  # This will use the Makefile to compile the program
else
    echo "Makefile not found, aborting installation."
    exit 1
fi

# List all compiled files (this assumes 'gcal' is the executable created)
echo "Compiled files:"
ls -l gcal*  # This will list all files starting with 'gcal'

# Define the installation directory
INSTALL_DIR="$HOME/.local/bin"

# Create the directory if it does not exist
mkdir -p $INSTALL_DIR

# Stop any running 'gcal' processes to avoid 'Text file busy' error
killall gcal 2>/dev/null  # Ignore errors if no process is running

# Copy the executable to the installation directory
cp gcal $INSTALL_DIR

# Make sure the file is copied
echo "gcal copied to $INSTALL_DIR"

# Add the directory to the PATH in .bashrc if it's not already present
if ! grep -q "$INSTALL_DIR" "$HOME/.bashrc"; then
    echo "export PATH=\"$INSTALL_DIR:\$PATH\"" >> "$HOME/.bashrc"
    echo "PATH updated in .bashrc"
else
    echo "PATH already updated in .bashrc"
fi

# Reload .bashrc to apply changes
source "$HOME/.bashrc"

echo "Installation complete!"

