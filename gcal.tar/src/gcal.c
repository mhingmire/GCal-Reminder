#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_REMINDERS 100

typedef struct {
    int day;
    char note[50];
} Reminder;

Reminder reminders[MAX_REMINDERS][10];  // Multiple reminders per day (up to 10)
int reminder_count[31] = {0};  // Keeps track of reminder counts for each day (1-31)

const char *days_of_week[] = {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
};

void print_calendar() {
    printf("December 2024\n");
    printf("Sun Mon Tue Wed Thu Fri Sat\n");

    int days_in_month = 31;
    int start_day = 0; // Assuming December 1, 2024 is a Sunday

    
    for (int i = 0; i < start_day; i++) {
        printf("    ");
    }

    // Print the calendar days
    for (int day = 1; day <= days_in_month; day++) {
        if (reminder_count[day - 1] > 0) {  // Check if there are reminders for this day
            printf("(%2d) ", day);  // Add brackets around days with reminders
        } else {
            printf("%3d ", day);  // No brackets for days without reminders
        }

        if ((start_day + day) % 7 == 0) {
            printf("\n");
        }
    }
    printf("\n\n");


    // Print the reminders
    printf("December reminders:\n");
    for (int i = 0; i < 31; i++) {
        if (reminder_count[i] > 0) {
            for (int j = 0; j < reminder_count[i]; j++) {
                printf("%s %2d:: (%d) %s\n", days_of_week[(start_day + i) % 7], i + 1, j + 1, reminders[i][j].note);
            }
        }
    }
    printf("----------------------------------------\n");
}

void add_reminder(int day, const char *note) {
    
    int index = reminder_count[day - 1];
    reminders[day - 1][index].day = day;
    strncpy(reminders[day - 1][index].note, note, sizeof(reminders[day - 1][index].note) - 1);
    reminder_count[day - 1]++;
}

void remove_reminder(int day, int reminder_index) {
    if (reminder_index < 1 || reminder_index > reminder_count[day - 1]) {
        printf("Invalid reminder index for day %d.\n", day);
        return;
    }

    // Shift the reminders to remove the one at the given index
    for (int i = reminder_index - 1; i < reminder_count[day - 1] - 1; i++) {
        reminders[day - 1][i] = reminders[day - 1][i + 1];
    }
    reminder_count[day - 1]--;

}

void handle_command(char *command) {
    char subcommand[10];
    int day;
    char note[50];
    int reminder_index;

    // Check for the "view" command to display the calendar
    if (sscanf(command, "gcal %s", subcommand) == 1) {
        if (strcmp(subcommand, "view") == 0) {
            print_calendar();
        }
        // Handle the "add" command to add a reminder
        else if (strcmp(subcommand, "add") == 0) {
            if (sscanf(command, "gcal add %d %[^\n]", &day, note) == 2) {
                if (day < 1 || day > 31) {
                    printf("Invalid day.\n");
                } else {
                    add_reminder(day, note);
                    print_calendar();
                }
            } else {
                printf("Invalid add command format.\n");
            }
        }
        // Handle the "remove" command to remove a reminder
        else if (strcmp(subcommand, "remove") == 0) {
            if (sscanf(command, "gcal remove %d %d", &day, &reminder_index) == 2) {
                if (day < 1 || day > 31) {
                    printf("Invalid day.\n");
                } else {
                    remove_reminder(day, reminder_index);
                    print_calendar();
                }
            } else {
                printf("Invalid remove command format.\n");
            }
        }
        // Unknown subcommand
        else {
            printf("Unknown subcommand: %s. Please try again.\n", subcommand);
        }
    }
}

int main() {
    char command[100];

    printf("Enter command: ");
    while (fgets(command, sizeof(command), stdin) != NULL) {
        command[strcspn(command, "\n")] = 0; // Remove newline character
        handle_command(command);
        printf("\nEnter command: ");
    }

    return 0;
}

